package io.arshad.springbootstarter.topic;

import org.springframework.data.repository.CrudRepository;

// Uses the implementation that comes with Spring data JPA.
// CrudRepository is a generic type.
public interface TopicRepository extends CrudRepository<Topic, String> {
	
	
}
