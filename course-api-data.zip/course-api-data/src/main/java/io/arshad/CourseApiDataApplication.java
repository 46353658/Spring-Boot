package io.arshad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// The embedded database clears everything when you kill the server

// GET -> Get entry
// PUT -> Update entry
// POST -> Add entry
// DELETE -> Remove entry

@SpringBootApplication
public class CourseApiDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseApiDataApplication.class, args);
	}
}
