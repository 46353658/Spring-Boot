package io.arshad.springbootstarter.course;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

// Uses the implementation that comes with Spring data JPA.
// CrudRepository is a generic type.
public interface CourseRepository extends CrudRepository<Course, String> {
	/* You don't have to implement the method! Just declare the method with
	 * the findByProperty name format, and Spring Data JPA will implement
	 * the method for you! Make sure you write the method name in camel-case*/
	public List<Course> findByTopicId(String topicId);

}
